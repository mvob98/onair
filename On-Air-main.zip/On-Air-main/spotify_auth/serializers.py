from rest_framework import serializers
from .models import User, SpotifyToken


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["spotify_id", 'email', 'display_name', 'profile_image']


class SpotifyTokenSerializer(serializers.ModelSerializer):
    class Meta:
        model = SpotifyToken
        fields = '__all__'
