from django.urls import path, include
from rest_framework.routers import DefaultRouter

from .views import SpotifyCallbackView, SpotifyLogoutView

urlpatterns = [
    # path('login/', SpotifyAuthView.as_view(), name='spotify-login'),
    path('callback', SpotifyCallbackView.as_view(), name='spotify-callback'),

    path('logout/', SpotifyLogoutView.as_view(), name='spotify_logout')
]

app_name = "spotify-auth"

