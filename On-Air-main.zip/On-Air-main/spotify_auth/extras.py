from datetime import timedelta

import requests
from django.conf import settings
from django.utils import timezone

from on_air import settings
from spotify_auth.models import SpotifyToken  # Assuming you have this model
from user.models import User


def get_spotify_auth_response(request):
    code = request.GET.get('code')
    error = request.GET.get('error')
    if error:
        raise ValueError(f'Error from Spotify: {error}')

    token_response = requests.post('https://accounts.spotify.com/api/token', data={
        'grant_type': 'authorization_code',
        'code': code,
        'redirect_uri': settings.SPOTIFY_REDIRECT_URI,
        'client_id': settings.SPOTIFY_CLIENT_ID,
        'client_secret': settings.SPOTIFY_CLIENT_SECRET,
    })

    if token_response.status_code != 200:
        raise ValueError(f'Error fetching token from Spotify: {token_response.content}')

    return token_response.json()


def get_spotify_user_profile(access_token):
    user_profile_response = requests.get('https://api.spotify.com/v1/me', headers={
        'Authorization': f'Bearer {access_token}'
    })

    if user_profile_response.status_code != 200:
        raise ValueError(f'Error fetching user profile from Spotify: {user_profile_response.content}')

    return user_profile_response.json()


def update_or_create_user(spotify_id, display_name, email):
    user, user_created = User.objects.get_or_create(
        spotify_id=spotify_id,
        defaults={'spotify_id': spotify_id, 'display_name': display_name, 'email': email}
    )

    if not user_created:
        user.display_name = display_name
        user.email = email
        user.save()

    return user


def update_or_create_spotify_token(
        user,
        access_token,
        refresh_token,
        expires_in,
        token_type,
        scope
):
    token, token_created = SpotifyToken.objects.update_or_create(
        user=user,
        defaults={
            'access_token': access_token,
            'refresh_token': refresh_token,
            'expires_in': timezone.now() + timedelta(seconds=expires_in),
            'token_type': token_type,
            'scope': scope,
        }
    )

    if not token_created:
        token.access_token = access_token
        token.refresh_token = refresh_token
        token.expires_in = timezone.now() + timedelta(seconds=expires_in)
        token.token_type = token_type
        token.scope = scope
        token.save()

    return token


def refresh_spotify_token(refresh_token):
    token_response = requests.post('https://accounts.spotify.com/api/token', data={
        'grant_type': 'refresh_token',
        'refresh_token': refresh_token,
        'client_id': settings.SPOTIFY_CLIENT_ID,
        'client_secret': settings.SPOTIFY_CLIENT_SECRET,
    })

    if token_response.status_code != 200:
        raise ValueError(f'Error refreshing token from Spotify: {token_response.content}')

    return token_response.json()


def refresh_spotify_token(user):
    try:
        spotify_token = SpotifyToken.objects.get(user=user)
    except SpotifyToken.DoesNotExist:
        return None

    if not spotify_token.refresh_token:
        return None

    token_response = requests.post('https://accounts.spotify.com/api/token', data={
        'grant_type': 'refresh_token',
        'refresh_token': spotify_token.refresh_token,
        'client_id': settings.SPOTIFY_CLIENT_ID,
        'client_secret': settings.SPOTIFY_CLIENT_SECRET,
    })

    if token_response.status_code != 200:
        return None

    response_data = token_response.json()
    access_token = response_data.get('access_token')
    expires_in = response_data.get('expires_in')

    spotify_token.access_token = access_token
    spotify_token.expires_in = timezone.now() + timedelta(seconds=expires_in)
    spotify_token.save()

    return access_token


def check_and_refresh_spotify_token(user):
    try:
        spotify_token = SpotifyToken.objects.get(user=user)
    except SpotifyToken.DoesNotExist:
        return None

    if spotify_token.expires_in < timezone.now():
        return refresh_spotify_token(user)

    return spotify_token.access_token
