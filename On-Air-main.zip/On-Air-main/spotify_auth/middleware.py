from django.contrib.auth import get_user_model
from datetime import timedelta

from django.shortcuts import redirect
from django.utils import timezone
from rest_framework import status
from rest_framework.response import Response
from spotify_auth.models import SpotifyToken
from spotify_auth.extras import refresh_spotify_token, get_spotify_user_profile, check_and_refresh_spotify_token


class SpotifyTokenRefreshMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        one = request
        # Обробка Spotify токену тільки для аутентифікації через Spotify
        if 'spotify_access_token' in request.session:
            access_token = request.session['spotify_access_token']
            user = get_user_model().objects.get(spotify_token__access_token=access_token)
            check_and_refresh_spotify_token(user)

        response = self.get_response(request)
        return response
