from django.contrib.auth.models import AbstractBaseUser
from django.db import models

from user.models import User


class SpotifyToken(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="spotify_token")
    access_token = models.CharField(max_length=255)
    refresh_token = models.CharField(max_length=255)
    expires_in = models.DateTimeField()
    token_type = models.CharField(max_length=50)
    scope = models.CharField(max_length=255)

    def __str__(self):
        return f"{self.user.display_name}'s Spotify Token"
