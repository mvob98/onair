from django.contrib.auth import login
from django.contrib.auth import logout as django_logout
from django.db import transaction
from django.shortcuts import redirect
from rest_framework import status
from rest_framework.authentication import SessionAuthentication, BasicAuthentication
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.authentication import JWTAuthentication

from spotify_auth.extras import (
    get_spotify_auth_response,
    get_spotify_user_profile,
    update_or_create_user,
    update_or_create_spotify_token
)
from spotify_auth.models import SpotifyToken  # імпортуємо модель SpotifyToken
from spotify_auth.serializers import UserSerializer
from user.models import User


# class SpotifyAuthView(APIView):
#     permission_classes = [AllowAny]
#     def get(self, request):
#         scope = "user-read-private user-read-email"
#         auth_url = (
#             f"https://accounts.spotify.com/authorize?response_type=code&client_id={settings.SPOTIFY_CLIENT_ID}&scope={scope}&redirect_uri={settings.SPOTIFY_REDIRECT_URI}"
#         )
#         return redirect(auth_url)


class SpotifyCallbackView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        try:
            response_data = get_spotify_auth_response(request)
        except ValueError as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)

        access_token = response_data.get('access_token')
        refresh_token = response_data.get('refresh_token')
        expires_in = response_data.get('expires_in')
        token_type = response_data.get('token_type')
        scope = response_data.get('scope')

        if not access_token or not refresh_token:
            return Response({'error': 'No access or refresh token received'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            user_profile_data = get_spotify_user_profile(access_token)
        except ValueError as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)

        spotify_id = user_profile_data.get('id')
        display_name = user_profile_data.get('display_name')
        email = user_profile_data.get('email')

        try:
            with transaction.atomic():
                user = update_or_create_user(spotify_id, display_name, email)
                update_or_create_spotify_token(user, access_token, refresh_token, int(expires_in),
                                               token_type, scope)

        except Exception as e:
            return Response({'error': 'Transaction failed: ' + str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        request.session["spotify_access_token"] = access_token
        user.backend = 'django.contrib.auth.backends.ModelBackend'
        login(request, user)

        return redirect("user:manage")


class UserProfileView(APIView):
    authentication_classes = [SessionAuthentication, BasicAuthentication, JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user_profile = User.objects.get(user=request.user)
        serializer = UserSerializer(user_profile)

        return Response(serializer.data)



class SpotifyLogoutView(APIView):
    def post(self, request):
        try:
            # Отримуємо поточного користувача
            user = request.user

            # Видаляємо токени Spotify, якщо вони є
            try:
                spotify_token = SpotifyToken.objects.get(user=user)
                spotify_token.delete()
            except SpotifyToken.DoesNotExist:
                pass  # Якщо токен відсутній, просто пропускаємо

            # Виходимо з системи Django
            django_logout(request)

            return Response({"success": "Successfully logged out."}, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
