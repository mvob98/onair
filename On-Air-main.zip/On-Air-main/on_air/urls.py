
from django.contrib import admin
from django.urls import path, include

from user.views import ActivationView, JWTLogoutView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('auth/', include('djoser.urls')),
    path('auth/', include('djoser.urls.jwt')),
    path('auth/', include('djoser.social.urls')),

    path("auth/users/activation/<str:uid>/<str:token>", ActivationView.as_view()),

    path('auth/jwt/logout/', JWTLogoutView.as_view(), name='jwt_logout'),

    path('spotify-auth/', include('spotify_auth.urls')),\
    path('user/', include('user.urls')),
    path("ticket/", include("ticket.urls")),
    path('__debug__/', include('debug_toolbar.urls')),
]