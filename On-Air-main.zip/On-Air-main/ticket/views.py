from django.db import transaction
from django.db.models import ExpressionWrapper, Count, F, IntegerField, OuterRef, Subquery, Sum
from django.db.models.functions import Coalesce
from django.shortcuts import render
from rest_framework import viewsets, mixins, status
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from ticket.models import Event, Ticket, Order, Location, TicketType
from ticket.serializers import EventSerializer, OrderSerializer, LocationSerializer, \
    TicketTypeSerializer, OrderRetrieveSerializer, TicketSerializer, EventRetrieveSerializer
from user.permissions import IsSeller, IsAuthenticatedOrReadOnlyForSellers


# Create your views here.

class EventViewSet(viewsets.ModelViewSet):
    queryset = Event.objects.all()
    serializer_class = EventSerializer
    permission_classes = [IsAuthenticatedOrReadOnlyForSellers]

    def get_serializer_class(self):
        if self.action == "retrieve":
            return EventRetrieveSerializer
        return EventSerializer



    def perform_create(self, serializer):
        seller_user = self.request.user.seller_profile
        serializer.save(created_by=seller_user)


class LocationViewSet(viewsets.ModelViewSet):
    queryset = Location.objects.all()
    serializer_class = LocationSerializer
    permission_classes = [IsAuthenticated, IsSeller]


class TicketCreateViewSet(
    mixins.CreateModelMixin,
    viewsets.GenericViewSet
):
    queryset = Ticket.objects.all()
    serializer_class = TicketSerializer
    permission_classes = [IsAuthenticated, IsSeller]


class OrderViewSet(viewsets.ModelViewSet):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer
    permission_classes = (IsAuthenticated,)

    def get_queryset(self):
        queryset = self.queryset.filter(user=self.request.user)

        queryset = queryset.prefetch_related("tickets").annotate(
            num_tickets=ExpressionWrapper(
                Count("tickets"),
                output_field=IntegerField(),
            )
        )

        return queryset

    def perform_create(self, serializer):
        serializer.save(
            user=self.request.user
        )

    def get_serializer_class(self):
        if self.action == "retrieve":
            return OrderRetrieveSerializer
        return OrderSerializer


class TicketTypeViewSet(viewsets.ModelViewSet):
    queryset = TicketType.objects.all()
    serializer_class = TicketTypeSerializer
