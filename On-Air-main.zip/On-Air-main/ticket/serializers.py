from django.db import transaction
from rest_framework import serializers

from ticket.models import Event, Ticket, Order, Location, TicketType


class EventSerializer(serializers.ModelSerializer):
    available_tickets = serializers.SerializerMethodField()

    class Meta:
        model = Event
        fields = (
            "id",
            "name",
            "start_time",
            "available_tickets",
            "location"
        )
        extra_kwargs = { # Поле event лише для запису
            'location': {'write_only': True}
        }

    def get_available_tickets(self, obj):
        return obj.get_available_tickets()


class EventRetrieveSerializer(serializers.ModelSerializer):
    created_by = serializers.SlugRelatedField(
        "organization_email",
        read_only=True
    )

    # ticket_types = serializers.SlugRelatedField(slug_field="type_name", many=True, read_only=True)
    available_tickets = serializers.SerializerMethodField()

    class Meta:
        model = Event
        fields = (
            "id",
            "name",
            "start_time",
            "location",
            "description",
            "created_by",
            # "ticket_types",
            "available_tickets"
        )
        read_only_fields = ("created_by",)

    def get_available_tickets(self, obj):
        return obj.get_available_tickets()


class TicketTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = TicketType
        fields = ('type_name', 'price', 'total_quantity', "event")


class LocationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Location
        fields = "__all__"


class TicketSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ticket
        fields = ("id", "event", "ticket_type")


class TicketRetrieveSerializer(serializers.ModelSerializer):
    event = serializers.SlugRelatedField(slug_field="name", many=False, read_only=True)
    ticket_type = serializers.SlugRelatedField(slug_field="type_name", many=False, read_only=True)
    ticket_price = serializers.ReadOnlyField(source='ticket_type.price')

    class Meta:
        model = Ticket
        fields = ("id", "event", "ticket_type", "ticket_price")


class OrderSerializer(serializers.ModelSerializer):
    num_tickets = serializers.IntegerField(read_only=True)
    tickets = TicketSerializer(many=True)

    class Meta:
        model = Order
        fields = ("id", "order_date", "num_tickets", "tickets",)
        extra_kwargs = {  # Поле event лише для запису
            'tickets': {'write_only': True}
        }

    @transaction.atomic
    def create(self, validated_data):
        tickets_data = validated_data.pop("tickets")
        total_price = 0

        # Calculate total price based on ticket prices+
        for ticket_data in tickets_data:
            ticket_type = ticket_data["ticket_type"]
            ticket_quantity = ticket_data.get("quantity", 1)  # Assuming default quantity is 1
            total_price += ticket_type.price * ticket_quantity

        # Create the order with the calculated total price
        with transaction.atomic():
            order = Order.objects.create(total_price=total_price, **validated_data)

            # Create tickets associated with the order
            for ticket_data in tickets_data:
                Ticket.objects.create(order=order, **ticket_data)

        return order

    def validate(self, data):
        tickets_data = data.get('tickets', [])
        if not tickets_data:
            raise serializers.ValidationError("Необхідно додати хоча б один квиток.")

        ticket_type_counts = {}
        for ticket_data in tickets_data:
            ticket_type = ticket_data['ticket_type']
            if ticket_type not in ticket_type_counts:
                ticket_type_counts[ticket_type] = 0
            ticket_type_counts[ticket_type] += 1

        for ticket_type, count in ticket_type_counts.items():
            ticket_type_instance = TicketType.objects.get(id=ticket_type.id)
            available_tickets = ticket_type_instance.total_quantity

            # Додаємо перевірку на кількість вже проданих квитків
            sold_tickets = Ticket.objects.filter(ticket_type=ticket_type, is_valid=True).count()
            remaining_tickets = available_tickets - sold_tickets

            if count > remaining_tickets:
                raise serializers.ValidationError({
                    'tickets': f'Квитків  {ticket_type_instance.type_name} більше не залишилось'
                })
        return data


class OrderRetrieveSerializer(serializers.ModelSerializer):

    tickets = TicketRetrieveSerializer(many=True)
    # user = serializers.SlugRelatedField(slug_field="email", read_only=True, many=False)

    class Meta:
        model = Order
        fields = (
            "id",
            "user",
            "order_date",
            "tickets",
            "total_price",
        )
        read_only_fields = ("user", )


