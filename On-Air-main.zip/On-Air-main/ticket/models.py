import uuid

from django.db import models

from on_air import settings


# from user.models import Seller


# Create your models here.
class Event(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField(max_length=3000)
    start_time = models.DateTimeField(auto_now_add=False)
    created_by = models.ForeignKey("user.Seller", on_delete=models.CASCADE, related_name="created_events")

    location = models.ForeignKey(
        "Location",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="location_event"
    )

    def __str__(self):
        return self.name

    def get_available_tickets(self):
        available_tickets = {}
        for ticket_type in self.ticket_types.all():
            available_tickets[ticket_type.type_name] = ticket_type.available_tickets()
        return available_tickets


class TicketType(models.Model):
    event = models.ForeignKey("Event", on_delete=models.CASCADE, related_name="ticket_types")
    type_name = models.CharField(max_length=100)  # Наприклад, 'Стандартний', 'ВІП'
    price = models.DecimalField(max_digits=10, decimal_places=2)
    total_quantity = models.IntegerField()

    def __str__(self):
        return f"{self.type_name} for {self.event.name}"

    def available_tickets(self):
        sold_tickets = self.ticket_types.filter(is_valid=True).count()
        return self.total_quantity - sold_tickets

class Location(models.Model):
    name = models.CharField(max_length=255)
    address = models.CharField(max_length=255)
    latitude = models.DecimalField(max_digits=9, decimal_places=6)
    longitude = models.DecimalField(max_digits=9, decimal_places=6)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name



class Order(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    order_date = models.DateTimeField(auto_now_add=True)
    total_price = models.DecimalField(max_digits=10, decimal_places=2)


class Ticket(models.Model):

    order = models.ForeignKey(Order, related_name='tickets', on_delete=models.CASCADE)
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name="tickets")
    ticket_type = models.ForeignKey(TicketType, on_delete=models.CASCADE, related_name="ticket_types")
    ticket_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    #qr_code = models.ImageField(upload_to='qrcodes/', blank=True, null=True)  # Для зберігання QR-кодів
    is_valid = models.BooleanField(default=True)

    def __str__(self):
        return f"Order {self.id} by {self.order.user}"
