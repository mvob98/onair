from django.urls import path, include

from rest_framework.routers import DefaultRouter

from ticket import views
from ticket.views import OrderViewSet

routers = DefaultRouter()

routers.register("event", views.EventViewSet)
routers.register("create-ticket", views.TicketCreateViewSet)
routers.register("order", views.OrderViewSet)
routers.register("location", views.LocationViewSet)
routers.register("ticket-types", views.TicketTypeViewSet)


urlpatterns = [
    path("", include(routers.urls)),
]