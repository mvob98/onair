# Create your models here.
from django.contrib.auth.hashers import make_password
from django.contrib.auth.models import (
    AbstractUser,
    BaseUserManager,
)
from django.db import models
from django.utils.translation import gettext_lazy as _

from ticket.models import Ticket


class UserManager(BaseUserManager):
    def _create_user(self, email, password=None, spotify_id=None, display_name=None, **extra_fields):
        """Create and save a User with the given email, spotify_id, display name, and password."""
        if not email:
            raise ValueError('The Email must be set')
        email = self.normalize_email(email)
        user = self.model(email=email, spotify_id=spotify_id, display_name=display_name, **extra_fields)
        if password:
            user.password = make_password(password)
        user.save(using=self._db)
        return user

    def create_user(self, email, password=None, spotify_id=None, display_name=None, **extra_fields):
        extra_fields.setdefault('is_staff', False)
        extra_fields.setdefault('is_superuser', False)
        return self._create_user(email, password, spotify_id, display_name, **extra_fields)

    def create_superuser(self, email, password=None, spotify_id=None, display_name=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        return self._create_user(email, password, spotify_id, display_name, **extra_fields)


class User(AbstractUser):
    spotify_id = models.CharField(max_length=255, unique=True, blank=True, null=True)
    profile_image = models.URLField(blank=True, null=True)
    display_name = models.CharField(max_length=255, blank=True, null=True)
    tickets = models.ForeignKey(
        Ticket,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="buyer_ticket"
    )
    is_seller = models.BooleanField(default=False)

    # Поля використовані за замовчуванням Django
    username = None
    email = models.EmailField(_('email address'), unique=True, null=False, blank=False)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

    objects = UserManager()

    def __str__(self):
        return self.email


class Email(models.Model):
    email = models.CharField()


class Seller(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="seller_profile")
    organization_name = models.CharField(max_length=255)
    organization_email = models.EmailField()
    tickets = models.ForeignKey(
        Ticket,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="seller_ticket"
    )

    def __str__(self):
        return f"{self.organization_email}, {self.user.email}"
