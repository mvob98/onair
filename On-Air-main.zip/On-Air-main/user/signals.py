from django.db import IntegrityError
from django.db.models.signals import post_save
from django.dispatch import receiver

from user.models import Email, User, Seller


@receiver(post_save, sender=User)
def save_user_email(sender, instance, created, **kwargs):
    if created:
        # Check if the email already exists in Email table
        existing_email = Email.objects.filter(email=instance.email).first()
        if not existing_email:
            try:
                # Create a new Email object only if it doesn't already exist
                Email.objects.create(email=instance.email)
            except IntegrityError:
                # Handle the case where another concurrent process created the same email
                pass

#
# @receiver(post_save, sender=User)
# def create_seller_profile(sender, instance, created, **kwargs):
#     if created and instance.is_seller:


#
#
# @receiver(post_save, sender=User)
# def save_seller_profile(sender, instance, **kwargs):
#     if instance.is_seller and not hasattr(instance, 'seller_profile'):
#         Seller.objects.create(user=instance)
#     elif not instance.is_seller and hasattr(instance, 'seller_profile'):
#         instance.seller_profile.delete()
