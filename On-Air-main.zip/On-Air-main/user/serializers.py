from djoser.serializers import (
    UserCreateSerializer as BaseUserCreateSerializer,
    UserSerializer as BaseUserSerializer, ActivationSerializer
)
from rest_framework import serializers

from user.models import User, Seller


class UserCreateSerializer(BaseUserCreateSerializer):
    class Meta(BaseUserCreateSerializer.Meta):
        model = User
        fields = ('id', 'email', 'password', 'spotify_id', 'display_name', 'profile_image')


class UserSerializer(BaseUserSerializer):

    class Meta(BaseUserSerializer.Meta):
        model = User
        fields = (
            'id',
            "spotify_id",
            "first_name",
            "last_name",
            'email',
            'display_name',
            'profile_image',
            "is_active",
            "is_seller",
            "seller_profile",
        )
        read_only_fields = ("is_active", "spotify_id", "is_seller")

        def get_fields(self):
            fields = super().get_fields()
            # Перевіряємо, чи користувач є продавцем
            if not self.instance or not self.instance.is_seller:
                fields.pop('seller_profile')
            return fields


class ActivationAccountWithUidToken(ActivationSerializer):
    def create(self, validated_data):
        instance = super().create(validated_data)

        return instance


class SellerProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = Seller
        fields = ['organization_name', 'organization_email', "user"]
        read_only_fields = ("user", )
