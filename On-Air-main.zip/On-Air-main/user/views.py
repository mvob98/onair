import djoser.serializers
import djoser.views
from django.contrib.auth import logout as django_logout
from django.contrib.auth.tokens import default_token_generator
from django.shortcuts import redirect
from rest_framework import generics, viewsets, mixins
from rest_framework import status
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.tokens import RefreshToken, AccessToken

from user.models import Seller
from user.permissions import IsSeller
# from user.authentication import CombinedAuthentication
from user.serializers import UserSerializer, UserCreateSerializer, SellerProfileSerializer


# Create your views here.
class CreateUserView(generics.CreateAPIView):
    serializer_class = UserCreateSerializer


class ManageUserView(generics.RetrieveUpdateAPIView):
    serializer_class = UserSerializer
    permission_classes = (IsAuthenticated, )

    def get_object(self):
        return self.request.user


class ActivationView(APIView):
    permission_classes = [AllowAny]
    token_generator = default_token_generator

    def get(self, request, *args, **kwargs):
        uid = kwargs.get("uid")
        token = kwargs.get("token")

        data = {"uid": uid, "token": token}

        # Передаємо генератор токенів у контекст серіалізатора
        djoser_serializer = djoser.serializers.ActivationSerializer(
            data=data, context={"view": self}
        )

        if djoser_serializer.is_valid():
            user = djoser_serializer.user
            user.is_active = True
            user.save()
            return redirect("user:manage")
        else:
            return Response(
                djoser_serializer.errors, status=status.HTTP_400_BAD_REQUEST
            )


class JWTLogoutView(APIView):

    def post(self, request):
        try:
            refresh_token = request.data["refresh_token"]
            token = RefreshToken(refresh_token)

            token.blacklist()

            return Response({"message": "succeed"}, status=status.HTTP_205_RESET_CONTENT)
        except Exception as e:
            return Response(status=status.HTTP_400_BAD_REQUEST)
#
#
# class ToggleSellerStatusView(APIView):
#     permission_classes = [IsAuthenticated]
#
#     def post(self, request):
#         user = request.user
#         user.is_seller = not user.is_seller
#         user.save()
#
#         return Response({'is_seller': user.is_seller}, status=status.HTTP_200_OK)


class SellerProfileView(generics.GenericAPIView):
    serializer_class = SellerProfileSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        user = self.request.user
        return Seller.objects.filter(user=user).first()

    def get(self, request):
        seller_profile = self.get_object()
        if not seller_profile:
            return Response({'detail': 'Seller profile not found.'}, status=status.HTTP_404_NOT_FOUND)
        serializer = self.serializer_class(seller_profile)
        return Response(serializer.data)

    def post(self, request):
        user = request.user
        if self.get_object():
            return Response({'detail': 'Seller profile already exists.'}, status=status.HTTP_400_BAD_REQUEST)

        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            serializer.save(user=user)
            user.is_seller = True
            user.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request):
        seller_profile = self.get_object()
        if not seller_profile:
            return Response({'detail': 'Seller profile not found.'}, status=status.HTTP_404_NOT_FOUND)

        serializer = self.serializer_class(seller_profile, data=request.data, partial=False)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request):
        seller_profile = self.get_object()
        if not seller_profile:
            return Response({'detail': 'Seller profile not found.'}, status=status.HTTP_404_NOT_FOUND)

        serializer = self.serializer_class(seller_profile, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    # def perform_create(self, serializer):





    # def get(self, request):
    #     user = request.user
    #     if not user.is_seller:
    #         return Response({'error': 'User is not a seller'}, status=status.HTTP_400_BAD_REQUEST)
    #
    #     seller_profile = user.seller_profile
    #     serializer = SellerProfileSerializer(seller_profile)
    #     return Response(serializer.data)
    #
    #
    # def post(self, request):
    #     user = request.user
    #
    #     # Перевірка чи користувач є продавцем
    #     if not user.is_seller:
    #         return Response({'error': 'User is not a seller'}, status=status.HTTP_400_BAD_REQUEST)
    #
    #     # Отримання даних профілю продавця з тіла запиту
    #     data = request.data
    #
    #     # Якщо у користувача вже є профіль продавця, оновлюємо його; інакше створюємо новий
    #     seller_profile, created = Seller.objects.get_or_create(user=user)
    #     serializer = SellerProfileSerializer(seller_profile, data=data, partial=True)
    #
    #     if serializer.is_valid():
    #         serializer.save()
    #         return Response(serializer.data, status=status.HTTP_200_OK)
    #     else:
    #         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    #
    #
    # def put(self, request):
    #     user = request.user
    #     if not user.is_seller:
    #         return Response({'error': 'User is not a seller'}, status=status.HTTP_400_BAD_REQUEST)
    #
    #     seller_profile = user.seller_profile
    #     serializer = SellerProfileSerializer(seller_profile, data=request.data, partial=True)
    #     if serializer.is_valid():
    #         serializer.save()
    #         return Response(serializer.data)
    #     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class OnlySellerView(APIView):
    permission_classes = [IsAuthenticated, IsSeller]

    def get(self, request):
        return Response({"message": "if you can read this email you're seller"})